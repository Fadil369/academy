<?php
require(__DIR__ . '/../../config.php');
redirect(new moodle_url('/local/brainsait/manage.php'));
