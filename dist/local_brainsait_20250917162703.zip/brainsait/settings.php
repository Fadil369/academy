<?php
defined('MOODLE_INTERNAL') || die();

if ($hassiteconfig) {
    $ADMIN->add('localplugins', new admin_externalpage(
        'local_brainsait_manage',
        get_string('pluginname', 'local_brainsait'),
        new moodle_url('/local/brainsait/manage.php'),
        'local/brainsait:manage'
    ));
}
